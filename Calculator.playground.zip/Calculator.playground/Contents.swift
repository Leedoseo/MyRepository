// import UIKit

//var greeting = "Hello, playground"

class Caluculator {
    // Todo : 내부 구현하기
    
    func calculate(_ operatory: Character, _ firstNumber: Int, _ secondNumber: Int) -> Int {
        
        // operator에 따라 프로퍼티의 함수를 실행시킴
        
        switch operatory {
        case "+" :
            return AddOperation.operate(firstNumber, secondNumber)
        case "-":
            return SubstractOperation.operate(firstNumber, secondNumber)
        case"×":
            return MultiplyOperation.operate(firstNumber, secondNumber)
        case"÷":
            return DivideOperation.operate(firstNumber, secondNumber)
        case"%":
            return RemainderOperation.operate(firstNumber, secondNumber)
        
        default :
            return 0
        }
    }
}
// 위 사칙연산 기호를 입력시 [덧셈 뺄셈 곱셈 나눗셈] firstNumber 과 secondNumber 사이에 기호의 역할?을 한다??

class AddOperation {
    static func operate(_ firstNumber: Int, _ secondNumber: Int) -> Int {
        return (firstNumber + secondNumber)
    }
}

class SubstractOperation {
    static func operate(_ firstNumber: Int, _ secondNumber: Int) -> Int {
        return (firstNumber - secondNumber)
    }
}

class MultiplyOperation {
    static func operate(_ firstNumber: Int, _ secondNumber: Int) -> Int {
        return (firstNumber * secondNumber)
    }
}

class DivideOperation {
    static func operate(_ firstNumber: Int, _ secondNumber: Int) -> Int {
        return (firstNumber / secondNumber)
    }
}

class RemainderOperation {
    static func operate( _ firstNumber: Int, _ secondNumber: Int) -> Int {
        return (firstNumber % secondNumber)
    }
}

let calculator = Caluculator()// 프로퍼티 초기화
// Todo : calculator 변수를 활용하여 사칙연산을 진행

let addResult = calculator.calculate("+", 10, 3)// 덧셈 연산
let substractResult = calculator.calculate("-", 10, 3) // 뺄셈 연산
let multiplyResult = calculator.calculate("×", 10, 3)// 곱셈 연산
let divideResult = calculator.calculate("÷", 10, 3)// 나눗셈 연산
let remainderResult = calculator.calculate("%", 10, 3)// 나머지 연산


print("addResult : \(addResult)")
print("substractResult : \(substractResult)")
print("multiplyResult : \(multiplyResult)")
print("divideResult : \(divideResult)")
print("remainderResult : \(divideResult)")

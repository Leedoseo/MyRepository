// import UIKit

//var greeting = "Hello, playground"

class Caluculator {
    // Todo : 내부 구현하기
    
    func calculate(_ operatory: Character, _ firstNumber: Int, _ secondNumber: Int) -> Int {
        // Character를 Int로 변환
        
        switch operatory {
        case "+" : // 덧셈 연산
            return AddOperation.operate(firstNumber, secondNumber)
        case "-": // 뺄셈 연산
            return SubstractOperation.operate(firstNumber, secondNumber)
        case"×": // 곱셈 연산
            return MultiplyOperation.operate(firstNumber, secondNumber)
        case"÷": // 나눗셈 연산
            return DivideOperation.operate(firstNumber, secondNumber)
        case"%": // 나머지 연산
            return RemainderOperation.operate(firstNumber, secondNumber)
        
        default :
            return 0
        }
    }
}
// 위 사칙연산 기호를 입력시 아래위 class를 실행한다?

class AddOperation {
    static func operate(_ firstNumber: Int, _ secondNumber: Int) -> Int {
        return (firstNumber + secondNumber)
    } // firstNumber, secondNumber 둘다 Int 정수로 받고 정수로 출력
} // AddOperation은 firstNumber + secondNumber로 덧셈

class SubstractOperation {
    static func operate(_ firstNumber: Int, _ secondNumber: Int) -> Int {
        return (firstNumber - secondNumber)
    }
}

class MultiplyOperation {
    static func operate(_ firstNumber: Int, _ secondNumber: Int) -> Int {
        return (firstNumber * secondNumber)
    }
}

class DivideOperation {
    static func operate(_ firstNumber: Int, _ secondNumber: Int) -> Int {
        return (firstNumber / secondNumber)
    }
}

class RemainderOperation {
    static func operate(_ firstNumber: Int, _ secondNumber: Int) -> Int {
        return (firstNumber % secondNumber)
    }
}

let calculator = Caluculator()// calculator 초기화
// Todo : calculator 변수를 활용하여 사칙연산을 진행

let addResult = calculator.calculate("+", 10, 3)// 덧셈 연산
let substractResult = calculator.calculate("-", 10, 3) // 뺄셈 연산
let multiplyResult = calculator.calculate("×", 10, 3)// 곱셈 연산
let divideResult = calculator.calculate("÷", 10, 3)// 나눗셈 연산
let remainderResult = calculator.calculate("%", 10, 3)// 나머지 연산


print("addResult : \(addResult)")
print("substractResult : \(substractResult)")
print("multiplyResult : \(multiplyResult)")
print("divideResult : \(divideResult)")
print("remainderResult : \(divideResult)")
